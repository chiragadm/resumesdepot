# ResumesDepot

ResumesDepot is an application that let you store your JSON format based resumes to cloud and query it for later use. It uses Django framework for frontend and mongodb for backend.

# Installation:
Following are prerequisites softwares.
* Linux based OS
* Python3 (prefer 3.4 or above)
* Python3 Modules:
  * django
  * mongoengine
  * requests
* mongodb

